<template>
    <section class="mt-8">
      <h2 class="text-3xl font-bold mb-4">Marketplace Content</h2>
      <p class="mb-4">Explore & Support Poets</p>
      <p class="mb-4">
        Find your next favorite poem, book, or poetry-inspired product!
      </p>
      <ul class="mb-4">
        <li class="mb-2">• Digital Poems – Purchase exclusive digital poetry pieces</li>
        <li class="mb-2">• Printed Works – Buy poetry books, chapbooks, and limited-edition prints</li>
        <li class="mb-2">• Poetry Merchandise – Shop apparel, posters, mugs, and more</li>
        <li class="mb-2">• Custom Poetry Requests – Order personalized poetry from your favorite writers</li>
      </ul>
      <button class="bg-blue-500 text-white px-4 py-2 rounded mt-4">
        Browse the Marketplace
      </button>
    </section>
  </template>
  
  <script>
  export default {
    name: 'MarketplaceContent',
  };
  </script>
  
  <style scoped>
  /* Additional styling can be added here if needed */
  </style>
  