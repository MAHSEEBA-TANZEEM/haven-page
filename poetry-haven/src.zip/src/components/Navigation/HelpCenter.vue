<template>
    <div>
      <h1 class="text-center">Help Center</h1>
      <p class="text-center">This is the Help Center page content.</p>
    </div>
</template>
  
<script>
  export default {
    name: 'HelpCenter',
  };
</script>
  