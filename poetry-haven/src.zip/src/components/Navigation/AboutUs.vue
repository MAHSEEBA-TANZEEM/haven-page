<template>
    <div>
      <h1 class="text-center">About Us</h1>
      <p class="text-center">This is the About Us page content.</p>
    </div>
</template>
  
<script>
  export default {
    name: 'AboutUs',
  };
</script>
  