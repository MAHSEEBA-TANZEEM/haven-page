<template>
    <div>
      <h1 class="text-center">Blog</h1>
      <p class="text-center">This is the Blog page content.</p>
    </div>
</template>
  
<script>
  export default {
    name: 'Blog',
  };
</script>
  