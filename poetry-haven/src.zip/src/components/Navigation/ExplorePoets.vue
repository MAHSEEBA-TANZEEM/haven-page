<template>
    <div>
      <h1 class="text-center">Explore Poets</h1>
      <p class="text-center">This is the Explore Poets page content.</p>
    </div>
</template>
  
<script>
  export default {
    name: 'ExplorePoets',
  };
</script>
  